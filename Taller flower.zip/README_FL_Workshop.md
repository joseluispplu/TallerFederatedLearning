# Taller: Introducción al Federated Learning con Flower (3h)

Este repositorio contiene el cuaderno principal `FL_Workshop_Flower.ipynb` y ficheros de apoyo.

## Contenidos
- Cuaderno guiado con:
  - Setup del entorno
  - Baselines centralizados (KDD y MNIST)
  - Simulación federada (FedAvg/FedAdam/FedProx)
  - Experimentos IID vs no-IID
  - Métricas y gráficas
  - Extensiones: robustez, stragglers, DP (opcional)

## Requisitos
- Python 3.10+ recomendado
- Dependencias en `requirements.txt` o `environment.yml`

## Instalación rápida (pip)
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -r requirements.txt
```

## Instalación con conda
```bash
conda env create -f environment.yml
conda activate flflower
```

## Estructura sugerida
```
.
├── FL_Workshop_Flower.ipynb
├── requirements.txt
├── environment.yml
└── data/
    ├── kddcup99_10.csv         # (opcional, si no hay Internet)
    └── mnist/                  # (opcional, si no hay Internet)
```

## Ejecución
Abra `FL_Workshop_Flower.ipynb` en Jupyter/Lab y siga las secciones en orden. La libreta está pensada para cubrirse en ~3 horas con demostraciones y ejercicios guiados.
